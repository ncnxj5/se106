ID  :  5130379068
NAME:  陈悦昕
In this part I use three cutting ways: 
AVERAGE cut; 
two green building would not be next to; 
while puting buildings check out if the front lines fit the rule. 
If they are not , then just return and abandon this way.

For data structure, I write a class called "citymap" to store the buildings.
